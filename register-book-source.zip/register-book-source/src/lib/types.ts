export type AppRole =
  | "platform_owner"
  | "school_admin"
  | "headmaster"
  | "teacher"
  | "pending_school_admin";

export type Profile = {
  id: string;
  full_name: string;
  role: AppRole;
  school_id: string | null;
};

export type School = {
  id: string;
  name: string;
  contact_email: string;
  contact_phone: string | null;
  status: "pending" | "approved" | "rejected" | "suspended";
  created_at: string;
};

export type Student = {
  id: string;
  full_name: string;
  roll_number: string;
  class_name: string;
  section: string;
};