-- REGISTER BOOK DATABASE FOUNDATION
-- Run this whole file in Supabase SQL Editor on a NEW project.
-- This creates the initial multi-school schema and row-level security policies.
-- Never put the Supabase service_role key in browser code.

create extension if not exists pgcrypto;

create table if not exists public.schools (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  contact_email text not null,
  contact_phone text,
  status text not null default 'pending'
    check (status in ('pending','approved','rejected','suspended')),
  owner_user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'pending_school_admin'
    check (role in ('platform_owner','school_admin','headmaster','teacher','pending_school_admin')),
  school_id uuid references public.schools(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.school_classes (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  class_name text not null,
  section text not null default 'A',
  created_at timestamptz not null default now(),
  unique (school_id, class_name, section)
);

create table if not exists public.students (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  full_name text not null,
  roll_number text not null,
  class_name text not null,
  section text not null,
  photo_path text,
  academic_year text,
  created_at timestamptz not null default now(),
  unique (school_id, class_name, section, roll_number)
);

create table if not exists public.attendance_sessions (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  class_name text not null,
  section text not null,
  subject text not null,
  period_number integer not null,
  attendance_date date not null,
  submitted_by uuid not null references auth.users(id),
  submitted_at timestamptz,
  status text not null default 'pending' check (status in ('pending','submitted')),
  created_at timestamptz not null default now(),
  unique (school_id, class_name, section, attendance_date, period_number)
);

create table if not exists public.attendance_records (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.attendance_sessions(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  status text not null check (status in ('present','absent','late')),
  marked_by uuid not null references auth.users(id),
  marked_at timestamptz not null default now(),
  unique (session_id, student_id)
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', ''),
    'pending_school_admin'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

create or replace function public.submit_school_application(
  p_school_name text,
  p_contact_phone text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_school_id uuid;
  v_email text;
begin
  if v_user_id is null then
    raise exception 'You must be signed in to submit a school application.';
  end if;
  if length(trim(coalesce(p_school_name,''))) < 2 then
    raise exception 'Please enter a valid school name.';
  end if;
  select email into v_email from auth.users where id = v_user_id;
  if exists (select 1 from public.schools where owner_user_id = v_user_id) then
    raise exception 'A school application already exists for this account.';
  end if;

  insert into public.schools(name, contact_email, contact_phone, owner_user_id)
  values (trim(p_school_name), coalesce(v_email,''), nullif(trim(coalesce(p_contact_phone,'')),''), v_user_id)
  returning id into v_school_id;

  update public.profiles
  set full_name = coalesce(nullif(full_name,''), (select raw_user_meta_data->>'full_name' from auth.users where id=v_user_id)),
      role = 'pending_school_admin',
      school_id = v_school_id
  where id = v_user_id;

  return v_school_id;
end;
$$;

create or replace function public.approve_school_application(p_school_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'platform_owner'
  ) then
    raise exception 'Only the platform owner can approve school applications.';
  end if;

  update public.schools set status='approved' where id=p_school_id and status='pending';
  update public.profiles set role='school_admin'
  where school_id=p_school_id and role='pending_school_admin';
end;
$$;

create or replace function public.is_platform_owner()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role='platform_owner');
$$;

create or replace function public.my_school_id()
returns uuid
language sql stable security definer
set search_path = public
as $$
  select school_id from public.profiles where id=auth.uid();
$$;

alter table public.profiles enable row level security;
alter table public.schools enable row level security;
alter table public.school_classes enable row level security;
alter table public.students enable row level security;
alter table public.attendance_sessions enable row level security;
alter table public.attendance_records enable row level security;

drop policy if exists "profile self or owner read" on public.profiles;
create policy "profile self or owner read" on public.profiles
for select to authenticated
using (id=auth.uid() or public.is_platform_owner());

-- Users may edit their display name, but must never be able to change
-- their own role or school_id from the browser.
drop policy if exists "profile self update" on public.profiles;
create policy "profile self update" on public.profiles
for update to authenticated
using (id=auth.uid())
with check (id=auth.uid());

revoke update on public.profiles from authenticated;
grant update (full_name) on public.profiles to authenticated;

drop policy if exists "schools owner or school members read" on public.schools;
create policy "schools owner or school members read" on public.schools
for select to authenticated
using (owner_user_id=auth.uid() or public.is_platform_owner() or id=public.my_school_id());

drop policy if exists "owner manage schools" on public.schools;
create policy "owner manage schools" on public.schools
for update to authenticated
using (public.is_platform_owner())
with check (public.is_platform_owner());

drop policy if exists "school classes read own" on public.school_classes;
create policy "school classes read own" on public.school_classes
for select to authenticated using (school_id=public.my_school_id() or public.is_platform_owner());
drop policy if exists "school classes insert own admin" on public.school_classes;
create policy "school classes insert own admin" on public.school_classes
for insert to authenticated
with check (
  school_id=public.my_school_id()
  and exists(select 1 from public.profiles where id=auth.uid() and role in ('school_admin','headmaster'))
  and exists(select 1 from public.schools where id=school_id and status='approved')
);
drop policy if exists "school classes update own admin" on public.school_classes;
create policy "school classes update own admin" on public.school_classes
for update to authenticated
using (
  school_id=public.my_school_id()
  and exists(select 1 from public.profiles where id=auth.uid() and role in ('school_admin','headmaster'))
  and exists(select 1 from public.schools where id=school_id and status='approved')
)
with check (school_id=public.my_school_id());
drop policy if exists "school classes delete own admin" on public.school_classes;
create policy "school classes delete own admin" on public.school_classes
for delete to authenticated
using (school_id=public.my_school_id() and exists(select 1 from public.profiles where id=auth.uid() and role='school_admin'));

drop policy if exists "students read own school" on public.students;
create policy "students read own school" on public.students
for select to authenticated using (school_id=public.my_school_id() or public.is_platform_owner());
drop policy if exists "students insert own school admin" on public.students;
create policy "students insert own school admin" on public.students
for insert to authenticated
with check (
  school_id=public.my_school_id()
  and exists(select 1 from public.profiles where id=auth.uid() and role in ('school_admin','headmaster'))
  and exists(select 1 from public.schools where id=school_id and status='approved')
);
drop policy if exists "students update own school admin" on public.students;
create policy "students update own school admin" on public.students
for update to authenticated
using (
  school_id=public.my_school_id()
  and exists(select 1 from public.profiles where id=auth.uid() and role in ('school_admin','headmaster'))
  and exists(select 1 from public.schools where id=school_id and status='approved')
)
with check (school_id=public.my_school_id());
drop policy if exists "students delete own school admin" on public.students;
create policy "students delete own school admin" on public.students
for delete to authenticated
using (school_id=public.my_school_id() and exists(select 1 from public.profiles where id=auth.uid() and role='school_admin'));

drop policy if exists "attendance sessions read own school" on public.attendance_sessions;
create policy "attendance sessions read own school" on public.attendance_sessions
for select to authenticated using (school_id=public.my_school_id() or public.is_platform_owner());
drop policy if exists "attendance sessions insert own school" on public.attendance_sessions;
create policy "attendance sessions insert own school" on public.attendance_sessions
for insert to authenticated with check (school_id=public.my_school_id() and submitted_by=auth.uid());
drop policy if exists "attendance records read own school" on public.attendance_records;
create policy "attendance records read own school" on public.attendance_records
for select to authenticated using (exists(select 1 from public.attendance_sessions s where s.id=session_id and (s.school_id=public.my_school_id() or public.is_platform_owner())));
drop policy if exists "attendance records insert own school" on public.attendance_records;
create policy "attendance records insert own school" on public.attendance_records
for insert to authenticated
with check (marked_by=auth.uid() and exists(select 1 from public.attendance_sessions s where s.id=session_id and s.school_id=public.my_school_id()));

grant execute on function public.submit_school_application(text,text) to authenticated;
grant execute on function public.approve_school_application(uuid) to authenticated;
grant execute on function public.is_platform_owner() to authenticated;
grant execute on function public.my_school_id() to authenticated;

-- IMPORTANT: After creating your first account, promote that account to platform owner:
-- update public.profiles
-- set role = 'platform_owner'
-- where id = (select id from auth.users where email = 'YOUR-EMAIL-ADDRESS');
